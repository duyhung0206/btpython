angular.module('bms').factory('customer_model', function ($http) {
    API_GET_LIST_CUSTOMER   = BASE_URL + 'customer',
    API_ADD_NEW_CUSTOMER    = BASE_URL + 'customer',
    API_GET_INFO_CUSTOMER   = BASE_URL + 'customer/',
    API_SAVE_EDIT_CUSTOMER  = BASE_URL + 'customer/',
    API_DELETE_CUSTOMER     = BASE_URL + 'customer/';
    return {
        /*
        * api: API_GET_LIST
        * method: post
        * */
        addNewCustomer: function (newC) {
            return $http({
                headers: {
                    'Content-Type': 'application/json'
                },
                url: API_ADD_NEW_CUSTOMER,
                method: 'POST',
                data: newC
            });
        },
        /*
        * api: API_GET_LIST
        * method: get
        * */
        getAllCustomers: function () {
            return $http({
                headers: {
                    'Content-Type': 'application/json'
                },
                url: API_GET_LIST_CUSTOMER,
                method: "GET",
            });
        },
        /*
        * api: API_DELETE_CUS
        * method: delete
        * */
        deleteCustomer: function (id) {
            return $http({
                headers:{
                    'Content-Type':'application/json'
                },
                url: API_DELETE_CUSTOMER + id,
                method: 'DELETE'
            });
        },
        /*
        * api: API_GET_INFO_CUSTOMER
        * method: get
        * */
        loadCustomerData: function (id, type) {
            return $http({
                headers:{
                    'Content-Type':'application/json'
                },
                url: API_GET_INFO_CUSTOMER + id,
                method: 'GET',
                params: {type: type}
            });
        },

        /*
        * api: API_GET_INFO_CUSTOMER
        * method: put
        * */
        saveEditCustomer: function (customer_data) {
            return $http({
                headers:{
                    'Content-Type':'application/json'
                },
                url: API_SAVE_EDIT_CUSTOMER + customer_data.id,
                method: 'PUT',
                data: customer_data
            });
        },
        // getDebtList: function () {
        //     return $http({
        //         headers: {
        //             'Content-Type': 'application/json'
        //         },
        //         url: baseUrl + 'customer?debt=true',
        //         method: "GET",
        //     });
        // }
    }
})