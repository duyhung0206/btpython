angular.module('bms').controller('edit_customer_ctrl', function ($scope, $state)
{
    $state.go('customer_edit.info');
});