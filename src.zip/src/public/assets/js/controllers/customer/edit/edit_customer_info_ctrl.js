angular.module('bms').controller('edit_customer_info_ctrl', function ($scope, $stateParams, customer_model, Notification)
{
    $scope.loadCustomerData = function () {
        customer_model.loadCustomerData($stateParams.id, 'info')
            .then(function (response) {
                $scope.currentCustomer = response.data;
                $scope.nameCustomer = angular.copy($scope.currentCustomer.name);
            }).catch(function (response) {
                message = '';
                response.data.forEach(function(value){
                    message += value + '<br/>';
                })
                Notification.error(message);
            })
    }

    $scope.loadCustomerData();

    $scope.saveEditCustomer = function () {
        customer_model.saveEditCustomer($scope.currentCustomer)
            .then(function (response) {
                $scope.currentCustomer = response.data;
                $scope.nameCustomer = angular.copy($scope.currentCustomer.name);
                Notification.success('Save data customer success!');
            }).catch(function (response) {
                Notification.error(response.data);
            })
    }
});