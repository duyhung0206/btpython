angular.module('bms').controller('list_customer_ctrl', function (
    $scope, $rootScope,
    $state,
    $ngConfirm,
    Notification,
    customer_model
) {
    $scope.Math = window.Math;
    $scope.defaultTable = {
        page_size : 10,
        field_search : '',
        current_page : 1,
        total_page : 0,
        total_records : [],
    }
    $scope.currentTable = angular.copy($scope.defaultTable);

    $scope.customers = [];
    $scope.reloadListCustomer = function () {
        customer_model.getAllCustomers()
            .then(function (response) {
                $scope.customers = response.data;
            }).catch(function (response) {
                message = '';
                response.data.forEach(function(value){
                    message += value + '<br/>';
                })
                Notification.error(message);
            });
    }
    $scope.reloadListCustomer();

    $rootScope.$on('reloadListCustomer', function (event, data) {
        $scope.currentTable = angular.copy($scope.defaultTable);
        $scope.reloadListCustomer();
    })

    $scope.editCustomer = function(id){
        $state.go("customer_edit.info", { id: id});
    }

    $scope.deleteCustomer = function(id){
        $ngConfirm({
            title: 'Delete user?',
            content: 'This dialog will automatically trigger \'cancel\' in 6 seconds if you don\'t respond.',
            autoClose: 'cancel|8000',
            buttons: {
                deleteUser: {
                    text: 'delete user',
                    btnClass: 'btn-red',
                    action: function () {
                        customer_model.deleteCustomer(id).then(function (response) {
                            $rootScope.$emit('reloadListCustomer');
                            Notification.success('Delete customer success!');
                        })
                    }
                },
                cancel: function () {
                    Notification.error('Cancel delete customer!');
                }
            }
        });
    }

})