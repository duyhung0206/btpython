angular.module('bms').controller('create_customer_ctrl',
    ['$scope', '$rootScope', 'customer_model', 'Notification',
function ($scope, $rootScope, customer_model, Notification)
{

    $scope.defaultNewCustomer = {
        name : '',
        email: '',
        address: '',
        phone: '',
        note:'',
        is_active: 1,
        type: -1
    }
    $scope.newC = angular.copy($scope.defaultNewCustomer);

    $scope.addNewCustomer = function () {
        customer_model.addNewCustomer($scope.newC)
            .then(function (response) {
                $rootScope.$emit('reloadListCustomer');
                $scope.formCreateCustomer.$setUntouched();
                Notification.success('Create customer success!');
                $scope.newC = angular.copy($scope.defaultNewCustomer);
            }).catch(function (response) {
                message = '';
                response.data.forEach(function(value){
                    message += value + '<br/>';
                })
                Notification.error(message);
            });
    }


}]);