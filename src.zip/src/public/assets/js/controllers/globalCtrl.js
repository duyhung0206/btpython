app.controller('globalCtrl', ['$scope', function($scope){
     var main = [
        {
            title: 'Dash board',
            icon: 'fas fa-tachometer-alt',
            submenu:[],
            href: '#/dashboard'
        },
        {
            title: 'Customer',
            icon: 'far fa-user',
            submenu:[],
            href: '#/customer'
        },
        {
            title: 'Order',
            icon: 'fas fa-file-invoice',
            submenu:[
                {
                    title: 'List order',
                    icon: '',
                    href: '#/order'
                },
                {
                    title: 'Create new order',
                    icon: '',
                    href: '#/order/new'
                }
            ],
        },
        {
            title: 'Product',
            icon: 'fas fa-box-open',
            submenu:[],
            href: '#/product'
        },
        {
            title: 'Report',
            icon: 'fas fa-chart-pie',
            submenu:[],
            href: '#/report'
        },
    ]

    var action = [
        {
            title: 'Logout',
            icon: 'fas fa-sign-out-alt',
            submenu:[],
            href: '/logout'
        }
    ]
    $scope.menu = [
        {
            label: 'Main',
            menu: main
        },
        {
            label: 'Action',
            menu: action
        },
    ]

    $scope.show_nav = false;
}]);