app.config(function($stateProvider, $urlRouterProvider, $ocLazyLoadProvider) {

    $urlRouterProvider.otherwise('/dashboard');
    $ocLazyLoadProvider.config({
        loadedModules: ['bms'], modules: [
            {
                name: 'customer_index',
                files: [
                    'vendor/hades/assets/js/controllers/customer/index/create_customer_ctrl.js',
                    'vendor/hades/assets/js/controllers/customer/index/list_customer_ctrl.js',
                    'vendor/hades/assets/js/controllers/customer/customer_model.js',
                ]
            },
            {
                name: 'customer_edit',
                files: [
                    'vendor/hades/assets/js/controllers/customer/edit/edit_customer_ctrl.js',
                    'vendor/hades/assets/js/controllers/customer/customer_model.js',
                ]
            }
        ]
    })

    $stateProvider
        .state('dashboard', {
            url: '/dashboard',
            templateUrl: 'vendor/hades/assets/templates/dashboard/index.html',
            resolve: {
                deps: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        files: ['vendor/hades/assets/js/controllers/dashboardCtrl.js']
                    });
                }]
            }
        })
        .state('customer_index', {
            url: '/customer',
            templateUrl: 'vendor/hades/assets/templates/customer/index.html',
            resolve: {
                deps: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load('customer_index');
                }]
            }
        })
        .state('customer_edit', {
            url: '/customer/edit/:id',
            controller: 'edit_customer_ctrl',
            templateUrl: 'vendor/hades/assets/templates/customer/edit.html',
            resolve: {
                deps: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load('customer_edit');
                }]
            }
        })
        .state('customer_edit.info', {
            templateUrl: 'vendor/hades/assets/templates/customer/edit/info.html',
            controller: 'edit_customer_info_ctrl',
            resolve: {
                deps: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        files:[
                            'vendor/hades/assets/js/controllers/customer/edit/edit_customer_info_ctrl.js'
                        ]
                    });
                }]
            }

        })
        .state('customer_edit.orders', {
            templateUrl: 'vendor/hades/assets/templates/customer/edit/orders.html',
        })
        .state('customer_edit.report', {
            templateUrl: 'vendor/hades/assets/templates/customer/edit/report.html',
        })

});