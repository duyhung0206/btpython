<!doctype html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="{{asset('vendor/hades/lib/bootstrap/css/bootstrap.css')}}">
    <link rel="stylesheet" href="{{asset('vendor/hades/theme/lumen/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('vendor/hades/assets/css/signin.css')}}">
</head>
<body class="text-center" cz-shortcut-listen="true">
    <form class="form-signin" action="{{url('login')}}" method="POST" role="form">
        <img class="mb-4" src="../../assets/brand/bootstrap-solid.svg" alt="" width="72" height="72">
        <h1 class="h3 mb-3 font-weight-normal">Please sign in</h1>
        @if($errors->has('errorlogin'))
            <div class="alert alert-danger">
                {{$errors->first('errorlogin')}}
            </div>
        @endif
        <label for="inputEmail" class="sr-only">Email address</label>
        <input type="email" id="email" name="email" class="form-control" placeholder="Email address" required value="{{old('email')}}">

        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" id="password" name="password" class="form-control" placeholder="Password" required="">
        @if($errors->has('email'))
            <p style="color:red">{{$errors->first('email')}}</p>
        @endif
        @if($errors->has('password'))
            <p style="color:red">{{$errors->first('password')}}</p>
        @endif
        <div class="checkbox mb-3">
            <label>
                <input type="checkbox" value="remember-me"> Remember me
            </label>
        </div>
        {!! csrf_field() !!}
        <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
        <p class="mt-5 mb-3 text-muted">© codeddow.com</p>
    </form>
</body>
</html>
