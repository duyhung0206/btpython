<?php

namespace Hades\App\Http\Controllers;

use Hades\App\Models\Customer;
use Hades\App\Models\Order;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use Auth;
class CustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $customers = Customer::all();
        foreach ($customers as &$customer){

            $orders = Order::where('customer_id', $customer->id)->get();
            $totalDebt = 0;

            foreach ($orders as $order){
                $totalDebt += $order->grand_total;
            }
            $customer->total_debt = $totalDebt;
        }

        return $customers;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $validator = Validator::make($request->all(), [
            'name' => 'required|unique:customer'
        ]);
        if ($validator->fails()) {
            return response($validator->errors()->all(), 422);
        }
        $customer = Customer::create([
            'name' => $request->input('name'),
            'type' => $request->input('type'),
            'email' => $request->input('email'),
            'address' => $request->input('address'),
            'phone' => $request->input('phone'),
            'note' => $request->input('note'),
            'is_active' => $request->input('is_active'),
            'created_by' => Auth::user()->email
        ]);
        return response($customer, 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  \Hades\App\Models\Customer $customer
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        if($request->has('type')){
            switch ($request->input('type')){
                case 'info':
                    $customer = Customer::find($id);
                    return $customer;
                    break;
                case 'orders':
                    break;
                case 'report':
                    break;
            }
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \Hades\App\Models\Customer $customer
     * @return \Illuminate\Http\Response
     */
    public function edit(Customer $customer)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Hades\App\Models\Customer $customer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $checkNameError = Customer::where('id', '<>', $id)->where('name', $request->input('name'))->count();

        if($checkNameError > 0){
            return response('The name has already been taken.', 422);
        }

        $customer = Customer::find($id);
        if($customer->id){
            $oldName = $customer->name;
            $customer->update([
                'name' => $request->input('name'),
                'type' => $request->input('type'),
                'email' => $request->input('email'),
                'address' => $request->input('address'),
                'phone' => $request->input('phone'),
                'note' => $request->input('note'),
                'is_active' => $request->input('is_active')
            ]);

            if($oldName != $customer->name){
                Order::where('customer_id', $customer->id)->update([
                    'customer_name' => $customer->name
                ]);
            }

            $customer = Customer::find($id);
            return $customer;
        }else{
            return response('Customer does not exist !', 422);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \Hades\App\Models\Customer $customer
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $customer = Customer::find($id);
        if($customer){
            /*Remove assign all order*/
            $orders = Order::where('customer_id', $customer->id);
            $orders->update([
                'customer_id' => 0
            ]);

            /*Delete customer*/
            $customer->delete();
            return Customer::all();
        }else{
            return response('Not found customer', 422);
        }
    }
}
