<?php

namespace Hades\App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'order';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'increment_id',
        'type',
        'order_date',
        'customer_id',
        'customer_name',
        'customer_email',
        'customer_phone',
        'note',
        'total_item_ordered',
        'total_item_refund',
        'total_amount_ordered',
        'total_amount_refund',
        'total_fee_need_pay',
        'total_fee',
        'total_paid',
        'subtotal',
        'grand_total',
        'created_by'
    ];

}
