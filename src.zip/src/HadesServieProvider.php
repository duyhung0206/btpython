<?php

namespace Hades;

use Illuminate\Support\ServiceProvider;

class HadesServieProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        $this->loadMigrationsFrom(__DIR__.'/database/migrations');

        /*load route*/
        $this->loadRoutesFrom(__DIR__.'/routes/web.php');

        /*load views*/
        $this->loadViewsFrom(__DIR__.'/resources/views', 'hades');

        /*
         * public asset
         * run php artisan vendor:publish --tag=hades_public --force
        */
        $this->publishes([
            __DIR__.'/public' => public_path('vendor/hades'),
        ], 'hades_public');
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
