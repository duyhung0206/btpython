<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCustomerTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('customer', function (Blueprint $table) {
            $table->increments('id');
            $table->smallInteger('type');
            $table->char('name', 255)->unique();
            $table->char('email', 255)->nullable();
            $table->char('address', 255)->nullable();
            $table->char('phone', 255)->nullable();
            $table->longText('note')->nullable();
            $table->smallInteger('is_active');
            $table->string('created_by');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('customer');
    }
}
