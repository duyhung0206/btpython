<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOrderTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('order', function (Blueprint $table) {
            $table->increments('id');
            $table->string('increment_id');
            $table->smallInteger('type');
            $table->date('order_date');
            $table->integer('customer_id');
            $table->string('customer_name');
            $table->string('customer_email');
            $table->string('customer_phone');
            $table->longText('note');
            $table->decimal('total_item_ordered', 16, 2);
            $table->decimal('total_item_refund', 16, 2);
            $table->decimal('total_amount_ordered', 16, 2);
            $table->decimal('total_amount_refund', 16, 2);
            $table->decimal('total_fee_need_pay', 16, 2);
            $table->decimal('total_fee', 16, 2);
            $table->decimal('total_paid', 16, 2);
            $table->decimal('subtotal', 16, 2);
            $table->decimal('grand_total', 16, 2);
            $table->string('created_by');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('order');
    }
}
