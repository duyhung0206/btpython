<?php

use Illuminate\Database\Seeder;
use Hades\App\Models\User;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        User::create([
            'name' => 'Hùng Nguyễn',
            'email' => 'hung02061994@gmail.com',
            'password' => bcrypt('Hh122122777')
        ]);
        User::create([
            'name' => 'admin',
            'email' => 'admin@example.com',
            'password' => bcrypt('admin123')
        ]);
    }
}
