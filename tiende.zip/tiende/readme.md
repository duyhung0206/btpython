## Install package
-   Add to conposer.json
```bash
"autoload": {
    "psr-4": {
        "Hades\\": "hades/src/"
    }
}
```
-   Add to config/app.php
```bash
'providers' => [
    /*
     * Package Service Providers...
     */
    Hades\App\Providers\HadesServieProvider::class
]
```
-   run php artisan vendor:publish --tag=public --force
