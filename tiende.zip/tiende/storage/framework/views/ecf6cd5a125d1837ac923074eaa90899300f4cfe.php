<!doctype html>
<html lang="en" class="no-js" ng-app="bms" ng-controller="global_ctrl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/hades/lib/fontawesome-free-5.2.0-web/css/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/hades/lib/bootstrap/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/hades/theme/lumen/bootstrap.min.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('vendor/hades/lib/angular-notification/angular-ui-notification.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('vendor/hades/lib/angular-confirm/angular-confirm.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('vendor/hades/assets/css/custom.css')); ?>">

    <title>BMS</title>

    <script type="text/javascript">
        var BASE_URL = "<?php echo e(url('/')); ?>/";
        var csrfToken = "<?php echo e(csrf_token()); ?>";
    </script>
</head>
<body cz-shortcut-listen="true">
    <div class="container-fluid">
        <ng-include src="'<?php echo e(asset('vendor/hades/assets/templates/partial/header.html')); ?>'"></ng-include>
        <div class="container-fluid view-content pt-3">
            <div ui-view></div>
        </div>
    </div>

    <script src="<?php echo e(asset('vendor/hades/lib/jquery/dist/jquery.js')); ?>"></script>

    <script src="<?php echo e(asset('vendor/hades/lib/bootstrap/js/bootstrap.js')); ?>"></script>

    <script src="<?php echo e(asset('vendor/hades/lib/angular/angular.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/hades/lib/angular-ui-router/angular-ui-router.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/hades/lib/angular-route/angular-route.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/hades/lib/ocLazyLoad/ocLazyLoad.js')); ?>"></script>

    
    <script src="<?php echo e(asset('vendor/hades/lib/angular-confirm/angular-confirm.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('vendor/hades/lib/angular-notification/angular-ui-notification.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/hades/assets/js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/hades/assets/js/angular-route.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/hades/assets/js/controllers/global_ctrl.js')); ?>"></script>
</body>
</html>