<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="<?php echo e(asset('vendor/hades/lib/bootstrap/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/hades/theme/lumen/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/hades/assets/css/signin.css')); ?>">
</head>
<body class="text-center" cz-shortcut-listen="true">
    <form class="form-signin" action="<?php echo e(url('login')); ?>" method="POST" role="form">
        <img class="mb-4" src="../../assets/brand/bootstrap-solid.svg" alt="" width="72" height="72">
        <h1 class="h3 mb-3 font-weight-normal">Please sign in</h1>
        <?php if($errors->has('errorlogin')): ?>
            <div class="alert alert-danger">
                <?php echo e($errors->first('errorlogin')); ?>

            </div>
        <?php endif; ?>
        <label for="inputEmail" class="sr-only">Email address</label>
        <input type="email" id="email" name="email" class="form-control" placeholder="Email address" required value="<?php echo e(old('email')); ?>">

        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" id="password" name="password" class="form-control" placeholder="Password" required="">
        <?php if($errors->has('email')): ?>
            <p style="color:red"><?php echo e($errors->first('email')); ?></p>
        <?php endif; ?>
        <?php if($errors->has('password')): ?>
            <p style="color:red"><?php echo e($errors->first('password')); ?></p>
        <?php endif; ?>
        <div class="checkbox mb-3">
            <label>
                <input type="checkbox" value="remember-me"> Remember me
            </label>
        </div>
        <?php echo csrf_field(); ?>

        <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
        <p class="mt-5 mb-3 text-muted">© codeddow.com</p>
    </form>
</body>
</html>
