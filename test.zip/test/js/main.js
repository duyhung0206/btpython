//Make the DIV element draggagle:


var dataSample = [
    {
        "index": "start",
        "status": false,
        "beforerun": false,
        "positionX": "291px",
        "positionY": "135px"
    },
    {
        "index": 1,
        "status": false,
        "beforerun": false,
        "positionX": "283px",
        "positionY": "160px"
    },
    {
        "index": 2,
        "status": false,
        "beforerun": false,
        "positionX": "273px",
        "positionY": "181px"
    },
    {
        "index": 3,
        "status": false,
        "beforerun": false,
        "positionX": "263px",
        "positionY": "199px"
    },
    {
        "index": 4,
        "status": false,
        "beforerun": false,
        "positionX": "251px",
        "positionY": "221px"
    },
    {
        "index": 5,
        "status": false,
        "beforerun": false,
        "positionX": "241px",
        "positionY": "245px"
    },
    {
        "index": 6,
        "status": false,
        "beforerun": false,
        "positionX": "231px",
        "positionY": "267px"
    },
    {
        "index": 7,
        "status": false,
        "beforerun": false,
        "positionX": "224px",
        "positionY": "291px"
    },
    {
        "index": 8,
        "status": false,
        "beforerun": false,
        "positionX": "212px",
        "positionY": "318px"
    },
    {
        "index": 9,
        "status": false,
        "beforerun": false,
        "positionX": "201px",
        "positionY": "339px"
    },
    {
        "index": 10,
        "status": false,
        "beforerun": false,
        "positionX": "198px",
        "positionY": "361px"
    },
    {
        "index": 11,
        "status": false,
        "beforerun": false,
        "positionX": "198px",
        "positionY": "388px"
    },
    {
        "index": 12,
        "status": false,
        "beforerun": false,
        "positionX": "185px",
        "positionY": "413px"
    },
    {
        "index": 13,
        "status": false,
        "beforerun": false,
        "positionX": "179px",
        "positionY": "436px"
    },
    {
        "index": 14,
        "status": false,
        "beforerun": false,
        "positionX": "177px",
        "positionY": "459px"
    },
    {
        "index": 15,
        "status": false,
        "beforerun": false,
        "positionX": "181px",
        "positionY": "487px"
    },
    {
        "index": 16,
        "status": false,
        "beforerun": false,
        "positionX": "202px",
        "positionY": "500px"
    },
    {
        "index": 17,
        "status": false,
        "beforerun": false,
        "positionX": "220px",
        "positionY": "522px"
    },
    {
        "index": 18,
        "status": false,
        "beforerun": false,
        "positionX": "240px",
        "positionY": "533px"
    },
    {
        "index": 19,
        "status": false,
        "beforerun": false,
        "positionX": "252px",
        "positionY": "555px"
    },
    {
        "index": 20,
        "status": false,
        "beforerun": false,
        "positionX": "261px",
        "positionY": "581px"
    },
    {
        "index": 21,
        "status": false,
        "beforerun": false,
        "positionX": "271px",
        "positionY": "605px"
    },
    {
        "index": 22,
        "status": false,
        "beforerun": false,
        "positionX": "283px",
        "positionY": "631px"
    },
    {
        "index": 23,
        "status": false,
        "beforerun": false,
        "positionX": "291px",
        "positionY": "654px"
    },
    {
        "index": 24,
        "status": false,
        "beforerun": false,
        "positionX": "298px",
        "positionY": "676px"
    },
    {
        "index": 25,
        "status": false,
        "beforerun": false,
        "positionX": "311px",
        "positionY": "710px"
    },
    {
        "index": 26,
        "status": false,
        "beforerun": false,
        "positionX": "316px",
        "positionY": "735px"
    },
    {
        "index": 27,
        "status": false,
        "beforerun": false,
        "positionX": "334px",
        "positionY": "774px"
    },
    {
        "index": 28,
        "status": false,
        "beforerun": false,
        "positionX": "376px",
        "positionY": "792px"
    },
    {
        "index": 29,
        "status": false,
        "beforerun": false,
        "positionX": "409px",
        "positionY": "801px"
    },
    {
        "index": 30,
        "status": false,
        "beforerun": false,
        "positionX": "451px",
        "positionY": "807px"
    },
    {
        "index": 31,
        "status": false,
        "beforerun": false,
        "positionX": "489px",
        "positionY": "816px"
    },
    {
        "index": 32,
        "status": false,
        "beforerun": false,
        "positionX": "521px",
        "positionY": "826px"
    },
    {
        "index": 33,
        "status": false,
        "beforerun": false,
        "positionX": "555px",
        "positionY": "836px"
    },
    {
        "index": 34,
        "status": false,
        "beforerun": false,
        "positionX": "588px",
        "positionY": "860px"
    },
    {
        "index": 35,
        "status": false,
        "beforerun": false,
        "positionX": "627px",
        "positionY": "852px"
    },
    {
        "index": 36,
        "status": false,
        "beforerun": false,
        "positionX": "662px",
        "positionY": "842px"
    },
    {
        "index": 37,
        "status": false,
        "beforerun": false,
        "positionX": "700px",
        "positionY": "822px"
    },
    {
        "index": 38,
        "status": false,
        "beforerun": false,
        "positionX": "743px",
        "positionY": "818px"
    },
    {
        "index": 39,
        "status": false,
        "beforerun": false,
        "positionX": "776px",
        "positionY": "825px"
    },
    {
        "index": 40,
        "status": false,
        "beforerun": false,
        "positionX": "808px",
        "positionY": "818px"
    },
    {
        "index": 41,
        "status": false,
        "beforerun": false,
        "positionX": "825px",
        "positionY": "781px"
    },
    {
        "index": 42,
        "status": false,
        "beforerun": false,
        "positionX": "834px",
        "positionY": "744px"
    },
    {
        "index": 43,
        "status": false,
        "beforerun": false,
        "positionX": "853px",
        "positionY": "716px"
    },
    {
        "index": 44,
        "status": false,
        "beforerun": false,
        "positionX": "871px",
        "positionY": "693px"
    },
    {
        "index": 45,
        "status": false,
        "beforerun": false,
        "positionX": "881px",
        "positionY": "669px"
    },
    {
        "index": 46,
        "status": false,
        "beforerun": false,
        "positionX": "886px",
        "positionY": "635px"
    },
    {
        "index": 47,
        "status": false,
        "beforerun": false,
        "positionX": "870px",
        "positionY": "605px"
    },
    {
        "index": 48,
        "status": false,
        "beforerun": false,
        "positionX": "848px",
        "positionY": "572px"
    },
    {
        "index": 49,
        "status": false,
        "beforerun": false,
        "positionX": "834px",
        "positionY": "548px"
    },
    {
        "index": 50,
        "status": false,
        "beforerun": false,
        "positionX": "823px",
        "positionY": "521px"
    },
    {
        "index": 51,
        "status": false,
        "beforerun": false,
        "positionX": "811px",
        "positionY": "493px"
    },
    {
        "index": 52,
        "status": false,
        "beforerun": false,
        "positionX": "790px",
        "positionY": "466px"
    },
    {
        "index": 53,
        "status": false,
        "beforerun": false,
        "positionX": "776px",
        "positionY": "443px"
    },
    {
        "index": 54,
        "status": false,
        "beforerun": false,
        "positionX": "762px",
        "positionY": "419px"
    },
    {
        "index": 55,
        "status": false,
        "beforerun": false,
        "positionX": "747px",
        "positionY": "397px"
    },
    {
        "index": 56,
        "status": false,
        "beforerun": false,
        "positionX": "731px",
        "positionY": "374px"
    },
    {
        "index": 57,
        "status": false,
        "beforerun": false,
        "positionX": "718px",
        "positionY": "343px"
    },
    {
        "index": 58,
        "status": false,
        "beforerun": false,
        "positionX": "713px",
        "positionY": "320px"
    },
    {
        "index": 59,
        "status": false,
        "beforerun": false,
        "positionX": "699px",
        "positionY": "297px"
    },
    {
        "index": 60,
        "status": false,
        "beforerun": false,
        "positionX": "661px",
        "positionY": "294px"
    },
    {
        "index": 61,
        "status": false,
        "beforerun": false,
        "positionX": "641px",
        "positionY": "276px"
    },
    {
        "index": 62,
        "status": false,
        "beforerun": false,
        "positionX": "622px",
        "positionY": "252px"
    },
    {
        "index": 63,
        "status": false,
        "beforerun": false,
        "positionX": "604px",
        "positionY": "230px"
    },
    {
        "index": 64,
        "status": false,
        "beforerun": false,
        "positionX": "591px",
        "positionY": "211px"
    },
    {
        "index": 65,
        "status": false,
        "beforerun": false,
        "positionX": "566px",
        "positionY": "204px"
    },
    {
        "index": 66,
        "status": false,
        "beforerun": false,
        "positionX": "542px",
        "positionY": "195px"
    },
    {
        "index": 67,
        "status": false,
        "beforerun": false,
        "positionX": "531px",
        "positionY": "172px"
    },
    {
        "index": 68,
        "status": false,
        "beforerun": false,
        "positionX": "511px",
        "positionY": "151px"
    },
    {
        "index": 69,
        "status": false,
        "beforerun": false,
        "positionX": "488px",
        "positionY": "132px"
    },
    {
        "index": 70,
        "status": false,
        "beforerun": false,
        "positionX": "474px",
        "positionY": "106px"
    },
    {
        "index": 71,
        "status": false,
        "beforerun": false,
        "positionX": "445px",
        "positionY": "85px"
    },
    {
        "index": 72,
        "status": false,
        "beforerun": false,
        "positionX": "425px",
        "positionY": "68px"
    },
    {
        "index": 73,
        "status": false,
        "beforerun": false,
        "positionX": "401px",
        "positionY": "91px"
    },
    {
        "index": 74,
        "status": false,
        "beforerun": false,
        "positionX": "376px",
        "positionY": "105px"
    },
    {
        "index": 75,
        "status": false,
        "beforerun": false,
        "positionX": "350px",
        "positionY": "96px"
    },
    {
        "index": 76,
        "status": false,
        "beforerun": false,
        "positionX": "321px",
        "positionY": "91px"
    },
    {
        "index": 77,
        "status": false,
        "beforerun": false,
        "positionX": "309px",
        "positionY": "114px"
    }
]