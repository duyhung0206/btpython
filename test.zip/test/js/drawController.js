app.directive('shortcut', function() {
    return {
        restrict: 'E',
        replace: true,
        scope: true,
        link:    function postLink(scope, iElement, iAttrs){
            jQuery(document).on('keypress', function(e){
                scope.$apply(scope.keyPressed(e));
            });
            // jQuery(document).on('contextmenu', function(e){
            //     scope.$apply(scope.rightClick(e));
            // });
        }
    };
});
var currentX = currentY = 0;

$(document).mousemove(function(event) {
    currentX = event.pageX-8;
    currentY = event.pageY-18;
});

app.controller('drawController', function ($scope, $timeout) {
    $scope.index = 0;
    $scope.points = [];
    $scope.points = dataSample;
    window.onload = function(){
        $scope.points.forEach(function (element) {
            document.getElementById("point-" + element.index).style.left = element.positionX;
            document.getElementById("point-" + element.index).style.top = element.positionY;
        });
    }


    $scope.createStarted = false;
    $scope.addStartPoint = function () {
        $scope.createStarted = true;
        $scope.points.push({
            index: 'start',
            status: false,
            beforerun: false
        });
        $timeout(function () {
            dragElement(document.getElementById("point-start"));
            $scope.index ++;
        },50)
    }

    $scope.addPoint = function () {
        $scope.points.push({
            index: $scope.index,
            status: false,
            beforerun: false
        });
        $timeout(function () {
            dragElement(document.getElementById("point-" + $scope.index));
            document.getElementById("point-" + $scope.index).style.left = currentX+"px";
            document.getElementById("point-" + $scope.index).style.top = currentY+"px";
            $scope.index++;
        }, 20);
    }

    $scope.counter = 0;
    $scope.started = false;
    $scope.run = function(){
        if(!$scope.started){
            $scope.points.forEach(function (element) {
                element.beforerun = true;
            });
            $scope.started = true;
        }
        if ($scope.counter == $scope.points.length){
            $timeout.cancel($scope.mytimeout);
            return;
        }
        $scope.points[$scope.counter].status = true;
        $scope.points[$scope.counter].beforerun = false;
        $scope.counter++;
        $scope.mytimeout = $timeout($scope.run,200);
    }

    $scope.clearAll = function(){
        $scope.points = [];
        $scope.reset();
    }
    $scope.save = function(){
        $scope.dataSave = [];
        $scope.points.forEach(function (element) {
            element.positionX = document.getElementById("point-" + element.index).style.left;
            element.positionY = document.getElementById("point-" + element.index).style.top;
            $scope.dataSave.push(element);
        });
    }

    $scope.stop = function(){
        $timeout.cancel($scope.mytimeout);
    }

    $scope.reset = function(){
        $scope.points.forEach(function (element) {
            element.status = false;
            element.beforerun = false;
        });
        $scope.counter = 0;
        $scope.started = 0;
    }



    $scope.keyCode = "";
    $scope.keyPressed = function(e) {
        $scope.keyCode = e.which;
        if(e.which === 104){
            $scope.addPoint();
        }
    };

    function dragElement(elmnt) {
        var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
        if (document.getElementById(elmnt.id)) {
            /* if present, the header is where you move the DIV from:*/
            document.getElementById(elmnt.id).onmousedown = dragMouseDown;
        } else {
            /* otherwise, move the DIV from anywhere inside the DIV:*/
            elmnt.onmousedown = dragMouseDown;
        }

        function dragMouseDown(e) {
            e = e || window.event;
            e.preventDefault();
            // get the mouse cursor position at startup:
            pos3 = e.clientX;
            pos4 = e.clientY;
            document.onmouseup = closeDragElement;
            // call a function whenever the cursor moves:
            document.onmousemove = elementDrag;
        }

        function elementDrag(e) {
            e = e || window.event;
            e.preventDefault();
            // calculate the new cursor position:
            pos1 = pos3 - e.clientX;
            pos2 = pos4 - e.clientY;
            pos3 = e.clientX;
            pos4 = e.clientY;
            // set the element's new position:
            elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
            elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
        }

        function closeDragElement() {
            /* stop moving when mouse button is released:*/
            document.onmouseup = null;
            document.onmousemove = null;
        }
    }
});